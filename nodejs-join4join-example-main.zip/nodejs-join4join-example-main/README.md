# nodejs-join4join-example

example of join4join bot using the join4join api (https://join4join.xyz/documentation)

> System requirements to use this code
- NodeJS v16.9.0 or higher
- discordJS v14 

A guide to install NodeJS and DiscordJS: https://discordjs.guide/preparations/#installing-node-js

> Step 1
- Generate your api key on the website (https://join4join.xyz/profile)

> Step 2 
- Download the code

> Step 3
- edit the config.js file 
> token: your bot token
> 
> bot_invite_link: the link to invite your bot on others discord server
> 
> api_key: your api key generate on the join4join website

- run `npm install` & `node main.js`

Your Join4Join bot is ready enjoy!
- Developers receive 0.10 coins for each server farm with their bot from users create with the api.
- You can receive help here: https://discord.gg/tpEjXeZeVb
