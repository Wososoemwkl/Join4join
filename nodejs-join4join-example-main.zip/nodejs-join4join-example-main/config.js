module.exports = {
    token: "YOUR BOT TOKEN",
    bot_invite_link: "YOUR BOT INVITE LINK",
    url: "https://join4join.xyz",
    footer: "discord.gg/join4join",
    color: "#e84e4b",
    admin: [""],
    owner: [""],
    api_key: "YOUR API KEY (https://join4join.xyz/profile)",
    api_url: "https://join4join.xyz",
}